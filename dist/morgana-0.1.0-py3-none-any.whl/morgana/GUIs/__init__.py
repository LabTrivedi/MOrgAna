import morgana.GUIs.fluo
import morgana.GUIs.inspection
import morgana.GUIs.mainwindow
import morgana.GUIs.manualmask
# import orgseg.GUIs.spot
import morgana.GUIs.visualize0d
import morgana.GUIs.visualize1d
import morgana.GUIs.visualize2d
